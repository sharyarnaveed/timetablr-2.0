// import pkg from 'pg';
// import { DATABASE_NAME } from '../constants.js';
// const { Pool } = pkg;
const mysql = require('mysql2/promise');


const pool = mysql.createPool({
    host: 'premium104.web-hosting.com',
    user: 'prosxwdx_usetimetable',
    password: 'P!Co3JQnTK3&',
    database: 'prosxwdx_timetablr',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

// console.log(`${process.env.HOST_NAME}`);


// export {pool}
module.exports = { pool };
