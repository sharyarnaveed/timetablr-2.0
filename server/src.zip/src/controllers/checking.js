const cehcking= async (req, res) => {
    res.send("2.0");
    };


    module.exports={cehcking}